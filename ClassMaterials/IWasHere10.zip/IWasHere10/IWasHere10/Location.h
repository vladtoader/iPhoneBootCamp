//
//  Location.h
//  IWasHere10
//
//  Created by Arek Zarycki on 6/19/11.
//  Copyright (c) 2011 bep. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Location : NSManagedObject {
@private
}
@property (nonatomic, retain) NSString * Title;
@property (nonatomic, retain) NSNumber * Lat;
@property (nonatomic, retain) NSNumber * Lon;
@property (nonatomic, retain) NSDate * Timestamp;

@end
