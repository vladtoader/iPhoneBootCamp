//
//  IWasHere10AppDelegate.h
//  IWasHere10
//
//  Created by Arek Zarycki on 6/19/11.
//  Copyright 2011 bep. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IWasHere10AppDelegate : NSObject <UIApplicationDelegate> {
    UITabBarController *rootController;
}

@property (nonatomic, retain) IBOutlet UITabBarController *rootController;

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@end
