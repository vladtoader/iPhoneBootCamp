//
//  Location.m
//  IWasHere10
//
//  Created by Arek Zarycki on 6/19/11.
//  Copyright (c) 2011 bep. All rights reserved.
//

#import "Location.h"


@implementation Location
@dynamic Title;
@dynamic Lat;
@dynamic Lon;
@dynamic Timestamp;

@end
