//
//  ViewLocation.h
//  IWasHere10
//
//  Created by Arek Zarycki on 6/19/11.
//  Copyright 2011 bep. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>


@interface ViewLocation : UIViewController {
    MKMapView *map;
}

@property (nonatomic, retain) IBOutlet MKMapView *map;

@end
