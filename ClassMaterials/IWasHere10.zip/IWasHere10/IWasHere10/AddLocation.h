//
//  AddLocation.h
//  IWasHere10
//
//  Created by Arek Zarycki on 6/19/11.
//  Copyright 2011 bep. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>


@interface AddLocation : UIViewController<CLLocationManagerDelegate> {
    UITextField *xTitle;
    UILabel *dateLbl;
    UILabel *addressLbl;
    CLLocationManager *clManager;
    double lat;
    double lon;
}

@property (nonatomic, retain) CLLocationManager *clManager;
@property (nonatomic, retain) IBOutlet UITextField *xTitle;
@property (nonatomic, retain) IBOutlet UILabel *dateLbl;
@property (nonatomic, retain) IBOutlet UILabel *addressLbl;

-(IBAction)addLocation;

@end
