//
//  AddLocation.m
//  IWasHere10
//
//  Created by Arek Zarycki on 6/19/11.
//  Copyright 2011 bep. All rights reserved.
//

#import "AddLocation.h"
#import "Location.h"
#import "IWasHere10AppDelegate.h"


@implementation AddLocation

@synthesize xTitle, dateLbl, addressLbl;
@synthesize clManager;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
    [clManager release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

-(void)viewWillAppear:(BOOL)animated
{
    
}

-(void)viewWillDisappear:(BOOL)animated{
    [clManager stopUpdatingLocation];
}

-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    lat = newLocation.coordinate.latitude;
    lon = newLocation.coordinate.longitude;
    addressLbl.text = [NSString stringWithFormat:@"%d - %d",newLocation.coordinate.latitude, newLocation.coordinate.longitude];
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"%@",error);
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.clManager = [[CLLocationManager alloc] init];
    self.clManager.delegate = self;
    self.clManager.desiredAccuracy = kCLLocationAccuracyKilometer;
    [clManager startUpdatingLocation];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(IBAction)addLocation
{
    NSManagedObjectContext *context = ((IWasHere10AppDelegate*)[[UIApplication sharedApplication] delegate]).managedObjectContext;
    
    Location *newLoc = (Location*)[NSEntityDescription insertNewObjectForEntityForName:@"Location" inManagedObjectContext:context];
    
    newLoc.Title = xTitle.text;
    newLoc.Lon = [NSNumber numberWithDouble:lon];
    newLoc.Lat = [NSNumber numberWithDouble:lat];
    newLoc.Timestamp = [NSDate date];
    
    NSError *err = nil;
    
    [context save:&err];
    
    if(err)
    {
        NSLog(@"%@",err);
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Success" message:@"Location added" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
        [alert release];
        
    }
    
}

@end
