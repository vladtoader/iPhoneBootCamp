//
//  tabAppDelegate.h
//  tab
//
//  Created by Arek Zarycki on 6/18/11.
//  Copyright 2011 bep. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface tabAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
