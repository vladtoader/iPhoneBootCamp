//
//  GoodNewsViewController.h
//  Switchy
//
//  Created by sysadminAZ on 12/18/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface GoodNewsViewController : UIViewController {

}

@end
